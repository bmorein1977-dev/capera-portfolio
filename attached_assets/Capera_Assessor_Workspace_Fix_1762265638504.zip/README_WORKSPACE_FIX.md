# Assessor Workspace Fix
Apply these steps to remove legacy candidates and show the correct allocations.

## 1) Run SQL cleanup
- `901_cleanup_assessor_workspace.sql`

## 2) Wire the fixed endpoint
In `server/routes.ts`:
```ts
import { getAssessorCandidates_Workspace } from './routes.assessorCandidates.fixed'
app.get('/assessors/:id/candidates', getAssessorCandidates_Workspace)
```

## 3) Remove demo fallback in the client
See `client.AssessorWorkspace.note.md` and ensure the Workspace uses the API output only.

## 4) Verify
- Log in as Clever Cloggs → Workspace should list only real allocated users (e.g., Test Inst, Test Elec).
- Assessment Dashboard should align with Workspace.
