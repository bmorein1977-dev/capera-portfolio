-- 901_cleanup_assessor_workspace.sql
-- Purge legacy allocations and assessments not tied to real, active users.
-- Uses CANDIDATE_ALLOCATIONS (assessor_id, candidate_id). Adjust if your table name differs.

-- 1) Remove allocations with missing users (candidate or assessor)
DO $$
BEGIN
  IF to_regclass('candidate_allocations') IS NOT NULL THEN
    DELETE FROM candidate_allocations ca
    WHERE NOT EXISTS (SELECT 1 FROM users u WHERE u.id = ca.candidate_id)
       OR NOT EXISTS (SELECT 1 FROM users a WHERE a.id = ca.assessor_id);
  END IF;
END $$;

-- 2) Remove assessments for missing candidates or assessors
DELETE FROM assessments a
WHERE NOT EXISTS (SELECT 1 FROM users u WHERE u.id = a.candidate_id)
   OR (a.assessor_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM users au WHERE au.id = a.assessor_id));

-- 3) (Optional) Archive known demo seed users by name (safe to comment out if not needed)
-- UPDATE users SET is_archived = TRUE WHERE display_name IN ('Emma Wilson','Alex Thompson');
