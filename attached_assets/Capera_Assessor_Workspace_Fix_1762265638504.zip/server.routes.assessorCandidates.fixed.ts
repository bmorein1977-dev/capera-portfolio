// server.routes.assessorCandidates.fixed.ts
// Robust endpoint for Assessor Workspace that only returns real, active allocations.
// Prefers candidate_allocations; falls back to assignment rows in assessments if needed.

import type { Request, Response } from 'express'
import { z } from 'zod'
import { db } from './storage'

export async function getAssessorCandidates_Workspace(req: Request, res: Response) {
  const assessorId = z.string().uuid().parse(req.params.id)

  const rows = await db.raw(`
    WITH alloc AS (
      SELECT DISTINCT u.id, u.display_name, u.email, u.job_role_id
      FROM candidate_allocations ca
      JOIN users u ON u.id = ca.candidate_id
      WHERE ca.assessor_id = $1
        AND u.is_archived IS NOT TRUE
    ),
    from_assignments AS (
      SELECT DISTINCT u.id, u.display_name, u.email, u.job_role_id
      FROM assessments a
      JOIN users u ON u.id = a.candidate_id
      WHERE a.assessor_id = $1
        AND a.is_assignment IS TRUE
        AND u.is_archived IS NOT TRUE
    )
    SELECT * FROM alloc
    UNION
    SELECT * FROM from_assignments
    ORDER BY display_name;
  `, [assessorId])

  res.json(rows)
}
