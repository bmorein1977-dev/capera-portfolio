// client.AssessorWorkspace.note.md
# Assessor Workspace Demo Fallback
Search your workspace component for any demo or fallback data like:
- `demoCandidates`, `seedCandidates`, or hardcoded arrays with names (Emma Wilson, Alex Thompson).
Remove these fallbacks so the UI only renders when the API returns rows.

For example (pseudo):
```ts
const { data } = useSWR(`/assessors/${assessorId}/candidates`)
// BEFORE: const list = data?.length ? data : demoCandidates
// AFTER:
const list = data ?? []
```

Also confirm the UI calls the *fixed* endpoint you wired:
`GET /assessors/:id/candidates` → `getAssessorCandidates_Workspace`
