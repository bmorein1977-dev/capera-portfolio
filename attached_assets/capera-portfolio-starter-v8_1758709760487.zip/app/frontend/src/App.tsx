import { Routes, Route, Link, Navigate } from 'react-router-dom'
import Login from './pages/Login'
import Register from './pages/Register'
import Dashboard from './pages/Dashboard'
import FrameworkBuilder from './pages/FrameworkBuilder'
import Templates from './pages/Templates'
import TemplateEditor from './pages/TemplateEditor'
import TemplateImport from './pages/TemplateImport'
import AssessmentRunner from './pages/AssessmentRunner'
import VerifierConsole from './pages/VerifierConsole'
import Reports from './pages/Reports'
import Clients from './pages/Clients'
import Protected from './components/Protected'
import { AuthProvider, useAuth } from './lib/auth'

function Nav() {
  const { user, logout } = useAuth()
  const canVerify = !!user && (user.role === 'Verifier' || user.role === 'Admin')
  const canSeeReports = !!user && (['Admin','Manager'].includes(user.role))
  return (
    <nav className="p-4 border-b bg-white">
      <div className="max-w-6xl mx-auto flex items-center gap-6">
        <Link to="/" className="font-semibold">Capera</Link>
        {user && <>
          <Link to="/dashboard" className="text-sm">Dashboard</Link>
          <Link to="/builder" className="text-sm">Builder</Link>
          <Link to="/templates" className="text-sm">Templates</Link>
          <Link to="/assess" className="text-sm">Assess</Link>
          {canVerify && <Link to="/verify" className="text-sm">Verify</Link>}
          {canSeeReports && <Link to="/reports" className="text-sm">Reports</Link>}
          {user && (user.role==='Admin') && <Link to="/clients" className="text-sm">Clients</Link>}
        </>}
        <div className="ml-auto text-sm">
          {user ? <button onClick={logout} className="underline">Sign out</button> : <Link to="/login" className="underline">Sign in</Link>}
        </div>
      </div>
    </nav>
  )
}

export default function App() {
  return (
    <AuthProvider>
      <div className="min-h-screen">
        <Nav />
        <main className="max-w-6xl mx-auto p-6">
          <Routes>
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/dashboard" element={<Protected><Dashboard /></Protected>} />
            <Route path="/builder" element={<Protected><FrameworkBuilder /></Protected>} />
            <Route path="/templates" element={<Protected><Templates /></Protected>} />
            <Route path="/templates/:id" element={<Protected><TemplateEditor /></Protected>} />
            <Route path="/templates/import" element={<Protected><TemplateImport /></Protected>} />
            <Route path="/assess" element={<Protected><AssessmentRunner /></Protected>} />
            <Route path="/verify" element={<Protected><VerifierConsole /></Protected>} />
            <Route path="/reports" element={<Protected><Reports /></Protected>} />
            <Route path="/clients" element={<Protected><Clients /></Protected>} />
          </Routes>
        </main>
      </div>
    </AuthProvider>
  )
}
