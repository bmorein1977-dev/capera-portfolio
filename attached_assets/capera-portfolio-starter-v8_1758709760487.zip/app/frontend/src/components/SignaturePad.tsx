import { useRef, useState } from 'react'
export default function SignaturePad({ onSave }: { onSave: (dataUrl: string) => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null); const [drawing, setDrawing] = useState(false)
  const pos = (e:any, c:HTMLCanvasElement)=>{const r=c.getBoundingClientRect();const p=e.touches?e.touches[0]:e;return{ x:p.clientX-r.left, y:p.clientY-r.top }}
  const start=(e:any)=>setDrawing(true); const end=()=>setDrawing(false)
  const move=(e:any)=>{ if(!drawing) return; const c=canvasRef.current!, ctx=c.getContext('2d')!, {x,y}=pos(e,c); ctx.fillRect(x,y,2,2) }
  const save=()=>onSave(canvasRef.current!.toDataURL('image/png')); const clear=()=>{const c=canvasRef.current!,ctx=c.getContext('2d')!;ctx.clearRect(0,0,c.width,c.height)}
  return (<div><canvas ref={canvasRef} width={500} height={150} className="border rounded bg-white" onMouseDown={start} onMouseUp={end} onMouseMove={move} onTouchStart={start} onTouchEnd={end} onTouchMove={move} />
  <div className="flex gap-2 mt-2"><button onClick={save} className="px-3 py-1 rounded bg-black text-white text-sm">Save</button><button onClick={clear} className="px-3 py-1 rounded border text-sm">Clear</button></div></div>)
}
