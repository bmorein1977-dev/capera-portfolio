import { useEffect, useState } from 'react'
import { db, Evidence } from '../lib/db'
import { api } from '../lib/api'
export default function EvidenceCapture() {
  const [files, setFiles] = useState<Evidence[]>([]); const [busy, setBusy] = useState(false)
  const refresh = async () => setFiles(await db.evidence.orderBy('created_at').reverse().toArray())
  useEffect(()=>{ refresh() }, [])
  const addFiles = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files; if (!f) return
    for (let i=0;i<f.length;i++){ const file=f[i]; await db.evidence.add({ filename:file.name, blob:file, created_at:Date.now() }) }
    await refresh()
  }
  const sync = async () => {
    setBusy(true)
    try {
      for (const ev of files){
        const form = new FormData(); form.append('file', ev.blob, ev.filename)
        await api.post('/uploads/upload', form, { headers: { 'Content-Type':'multipart/form-data' } })
        await db.evidence.delete(ev.id!)
      }
      await refresh(); alert('Sync complete')
    } catch(e:any){ alert('Sync error: ' + (e?.response?.data?.detail || e.message)) } finally { setBusy(false) }
  }
  return (<div className="p-4 border rounded bg-white">
    <div className="flex items-center justify-between mb-3">
      <div><div className="font-semibold">Evidence (offline)</div><div className="text-xs text-neutral-600">Files stored locally until you Sync.</div></div>
      <button onClick={sync} disabled={busy || files.length===0} className="px-3 py-1 rounded bg-black text-white text-sm">{busy ? 'Syncing...' : `Sync ${files.length} file(s)`}</button>
    </div>
    <input type="file" multiple onChange={addFiles} className="mb-3" />
    <ul className="space-y-2">{files.map(f => (<li key={f.id} className="text-sm flex items-center justify-between">
      <span>{f.filename}</span><button className="text-xs underline" onClick={async()=>{ await db.evidence.delete(f.id!); refresh() }}>Remove</button></li>))}</ul>
  </div>)
}
