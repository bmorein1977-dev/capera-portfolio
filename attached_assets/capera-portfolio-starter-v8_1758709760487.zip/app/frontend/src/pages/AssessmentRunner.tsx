import { useEffect, useState } from 'react'
import { api } from '../lib/api'
import SignaturePad from '../components/SignaturePad'
type Template = { id:number; name:string; element:string; proficiency:string; version:string }
type Client = { id:number; name:string; logo_path?:string }
type Line = { id:number; item_type:string; item_code:string; item_text:string; outcome:string; comments:string }
export default function AssessmentRunner() {
  const [templates, setTemplates] = useState<Template[]>([])
  const [selected, setSelected] = useState<number | null>(null)
  const [candidate, setCandidate] = useState('')
  const [assessmentId, setAssessmentId] = useState<number | null>(null)
  const [clients, setClients] = useState<Client[]>([])
  const [clientId, setClientId] = useState<number | ''>('')
  const [lines, setLines] = useState<Line[]>([])
  const [assessorSig, setAssessorSig] = useState<string | null>(null)
  const [candidateSig, setCandidateSig] = useState<string | null>(null)
  const [nameA, setNameA] = useState(''); const [nameC, setNameC] = useState('')
  useEffect(()=>{ (async()=>{ const res = await api.get('/templates'); setTemplates(res.data); try { const c = await api.get('/clients'); setClients(c.data) } catch {} })() }, [])
  const start = async () => { if (!selected || !candidate) return; const res = await api.post('/assessments', { candidate_name: candidate, template_id: selected }); setAssessmentId(res.data.id); const full = await api.get(`/assessments/${res.data.id}`); setLines(full.data.lines) }
  const setOutcome = (i:number, outcome:string) => { const c=[...lines]; c[i]={...c[i], outcome}; setLines(c) }
  const setComment = (i:number, comments:string) => { const c=[...lines]; c[i]={...c[i], comments}; setLines(c) }
  const saveLines = async () => { if (!assessmentId) return; await api.post(`/assessments/${assessmentId}/lines`, lines.map(l=>({ id:l.id, outcome:l.outcome, comments:l.comments }))) }
  const submit = async () => { await saveLines(); if (!assessmentId) return; const res = await api.post(`/assessments/${assessmentId}/submit`); alert('Submitted: ' + res.data.outcome) }
  const closeOut = async () => { await saveLines(); if (assessmentId && assessorSig) await api.post(`/signatures/${assessmentId}`, { role:'Assessor', name:nameA, data_url: assessorSig }); if (assessmentId && candidateSig) await api.post(`/signatures/${assessmentId}`, { role:'Candidate', name:nameC, data_url: candidateSig }); if (!assessmentId) return; const res = await api.post(`/assessments/${assessmentId}/close`); alert('Closed: ' + res.data.outcome) }
  return (<div className="space-y-4"><h1 className="text-2xl font-bold">Assessment Runner</h1>
    {!assessmentId && (<div className="p-4 border rounded bg-white space-y-2">
      <input className="w-full border p-2 rounded" placeholder="Candidate name" value={candidate} onChange={e=>setCandidate(e.target.value)} />
      <select className="w-full border p-2 rounded" value={selected || ''} onChange={e=>setSelected(Number(e.target.value))}><option value="" disabled>Select template</option>{templates.map(t => <option key={t.id} value={t.id}>{t.name} — {t.element} ({t.proficiency} v{t.version})</option>)}</select>
      <select className="w-full border p-2 rounded" value={clientId} onChange={e=>setClientId(e.target.value ? Number(e.target.value) : '')}>
            <option value="">(Optional) Select client</option>
            {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <button onClick={start} className="px-3 py-1 rounded bg-black text-white text-sm">Start</button></div>)}
    {assessmentId && (<div className="space-y-3">
      {lines.map((l,i)=>(<div key={l.id} className="p-3 border rounded bg-white"><div className="text-xs text-neutral-500">{l.item_type} • {l.item_code}</div>
        <div className="font-medium mb-2">{l.item_text}</div><div className="flex items-center gap-2 mb-2">{['C','SG','NA'].map(o=>(<button key={o} onClick={()=>setOutcome(i,o)} className={`px-2 py-1 rounded border text-sm ${l.outcome===o ? 'bg-black text-white' : ''}`}>{o}</button>))}</div>
        <textarea className="w-full border p-2 rounded" rows={2} placeholder="Comments" value={l.comments} onChange={e=>setComment(i, e.target.value)} /></div>))}
      <div className="grid md:grid-cols-2 gap-4">
        <div className="p-3 border rounded bg-white"><div className="font-semibold mb-2">Assessor Signature (optional)</div><input className="w-full border p-2 rounded mb-2" placeholder="Assessor name" value={nameA} onChange={e=>setNameA(e.target.value)} /><SignaturePad onSave={setAssessorSig} /></div>
        <div className="p-3 border rounded bg-white"><div className="font-semibold mb-2">Candidate Signature (optional)</div><input className="w-full border p-2 rounded mb-2" placeholder="Candidate name" value={nameC} onChange={e=>setNameC(e.target.value)} /><SignaturePad onSave={setCandidateSig} /></div>
      </div>
      <div className="flex gap-2"><button onClick={submit} className="px-3 py-2 rounded border">Submit (interim)</button><button onClick={closeOut} className="px-3 py-2 rounded bg-black text-white">Close Assessment</button><a href={`${api.defaults.baseURL}/assessment-pdf/${assessmentId}.pdf`} target="_blank" className="px-3 py-2 rounded border">Download PDF</a></div>
    </div>)}</div>)
}
