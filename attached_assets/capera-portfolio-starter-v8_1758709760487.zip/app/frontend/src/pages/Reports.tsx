import { useEffect, useState } from 'react'
import { api } from '../lib/api'
type Row = { candidate:string; skills_gap:number; competent:number; not_applicable:number; total:number }
export default function Reports() {
  const [rows, setRows] = useState<Row[]>([])
  const [heatmap, setHeatmap] = useState<{candidates:string[]; elements:string[]; matrix:number[][]}>({candidates:[], elements:[], matrix:[]})
  const [loading, setLoading] = useState(true)
  useEffect(()=>{ (async()=>{ const r1 = await api.get('/reports/skills-gaps'); const r2 = await api.get('/reports/skills-heatmap'); setRows(r1.data); setHeatmap(r2.data); setLoading(false) })() }, [])
  const max = Math.max(1, ...heatmap.matrix.flat())
  return (<div className="space-y-6">
    <h1 className="text-2xl font-bold">Reports</h1>
    <div className="flex gap-2">
      <a href={`${api.defaults.baseURL}/reports/skills-gaps.csv`} className="px-3 py-1 rounded border text-sm">Download CSV</a>
      <a href={`${api.defaults.baseURL}/reports/skills-gaps.pdf`} className="px-3 py-1 rounded border text-sm">Download PDF</a>
        <a href={`${api.defaults.baseURL}/reports/skills-gaps.xlsx`} className="px-3 py-1 rounded border text-sm">Download Excel</a>
    </div>
    <section>
      <h2 className="text-xl font-semibold mb-2">Skills Gaps (Totals)</h2>
      {loading ? <p>Loading...</p> : (<div className="overflow-x-auto"><table className="min-w-full border bg-white">
        <thead><tr className="bg-neutral-100 text-left"><th className="p-2 border">Candidate</th><th className="p-2 border">Skills Gap</th><th className="p-2 border">Competent</th><th className="p-2 border">N/A</th><th className="p-2 border">Total</th></tr></thead>
        <tbody>{rows.map(r => (<tr key={r.candidate}><td className="p-2 border">{r.candidate}</td><td className="p-2 border">{r.skills_gap}</td><td className="p-2 border">{r.competent}</td><td className="p-2 border">{r.not_applicable}</td><td className="p-2 border">{r.total}</td></tr>))}</tbody>
      </table></div>)}
    </section>
    <section>
      <h2 className="text-xl font-semibold mb-2">Skills-Gap Heatmap (SG count by Candidate × Element)</h2>
      {loading ? <p>Loading...</p> : (<div className="overflow-x-auto">
        <table className="border bg-white"><thead><tr className="bg-neutral-100"><th className="p-2 border">Candidate \ Element</th>
          {heatmap.elements.map(e => <th key={e} className="p-2 border whitespace-nowrap">{e}</th>)}</tr></thead>
          <tbody>{heatmap.candidates.map((c,i)=>(<tr key={c}><td className="p-2 border font-medium">{c}</td>
            {heatmap.matrix[i].map((v,j)=>(<td key={j} className="p-2 border"><div className="w-10 h-10" style={{ backgroundColor: `rgba(255,0,0,${v/max})` }} title={`${v}`} /></td>))}</tr>))}</tbody>
        </table></div>)}
    </section>
  </div>)
}
