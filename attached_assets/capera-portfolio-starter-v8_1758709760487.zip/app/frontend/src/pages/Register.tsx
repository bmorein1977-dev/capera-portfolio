import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api } from '../lib/api'
export default function Register() {
  const [email, setEmail] = useState(''); const [password, setPassword] = useState('')
  const [first, setFirst] = useState(''); const [last, setLast] = useState('')
  const [role, setRole] = useState('Assessor'); const [loading, setLoading] = useState(false); const [error, setError] = useState<string | null>(null)
  const nav = useNavigate()
  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault(); setLoading(true); setError(null)
    try { await api.post('/auth/register', { email, password, first_name:first, last_name:last, role }); nav('/login') }
    catch (err:any) { setError(err?.response?.data?.detail || 'Registration failed') } finally { setLoading(false) }
  }
  return (<div className="max-w-sm mx-auto">
    <h1 className="text-2xl font-bold mb-4">Create account</h1>
    <form onSubmit={onSubmit} className="space-y-3">
      <input className="w-full border p-2 rounded" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
      <input className="w-full border p-2 rounded" placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
      <div className="flex gap-2">
        <input className="w-full border p-2 rounded" placeholder="First name" value={first} onChange={e=>setFirst(e.target.value)} />
        <input className="w-full border p-2 rounded" placeholder="Last name" value={last} onChange={e=>setLast(e.target.value)} />
      </div>
      <select className="w-full border p-2 rounded" value={role} onChange={e=>setRole(e.target.value)}>
        <option>Assessor</option><option>Admin</option><option>Verifier</option><option>Candidate</option><option>Manager</option>
      </select>
      {error && <p className="text-sm text-red-600">{error}</p>}
      <button disabled={loading} className="w-full p-2 rounded bg-black text-white">{loading ? '...' : 'Create account'}</button>
    </form>
  </div>)
}
