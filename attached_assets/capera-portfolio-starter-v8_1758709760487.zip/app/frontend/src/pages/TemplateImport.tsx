import { useState } from 'react'
import { api } from '../lib/api'
export default function TemplateImport() {
  const [file, setFile] = useState<File | null>(null)
  const [log, setLog] = useState<string>('')
  const upload = async () => {
    if (!file) return
    const form = new FormData()
    form.append('file', file)
    const res = await api.post('/template-import/bulk_csv', form, { headers: { 'Content-Type':'multipart/form-data' } })
    setLog(JSON.stringify(res.data, null, 2))
  }
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Import Templates (CSV)</h1>
      <p className="text-sm text-neutral-700">Columns: <code>name, element, proficiency, version, type(K/P), code, text, guidance, is_optional, weight</code></p>
      <input type="file" accept=".csv,text/csv" onChange={e=>setFile(e.target.files?.[0] || null)} />
      <div className="flex gap-2"><button onClick={upload} className="px-3 py-1 rounded bg-black text-white text-sm" disabled={!file}>Upload</button></div>
      {log && <pre className="p-3 bg-neutral-100 rounded text-xs overflow-auto">{log}</pre>}
    </div>
  )
}
