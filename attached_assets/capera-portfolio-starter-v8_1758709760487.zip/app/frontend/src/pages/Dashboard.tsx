import { Link } from 'react-router-dom'
import EvidenceCapture from '../components/EvidenceCapture'
export default function Dashboard() {
  return (<div className="space-y-6">
    <h1 className="text-2xl font-bold">Dashboard</h1>
    <div className="grid md:grid-cols-2 gap-4">
      <div className="p-4 border rounded bg-white">
        <div className="font-semibold mb-2">Build your framework</div>
        <p className="text-sm text-neutral-600 mb-3">Start editing categories, elements, and templates.</p>
        <Link to="/builder" className="px-3 py-1 rounded bg-black text-white text-sm">Open Builder</Link>
      </div>
      <EvidenceCapture />
    </div>
  </div>)
}
