import { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { api } from '../lib/api'
type KI = { code:string; text:string; guidance?:string; is_optional?:boolean; weight?:number }
type PI = KI
export default function TemplateEditor() {
  const { id } = useParams(); const nav = useNavigate()
  const [name, setName] = useState(''); const [element, setElement] = useState('')
  const [proficiency, setProficiency] = useState('Basic'); const [version, setVersion] = useState('1.0')
  const [knowledge, setKnowledge] = useState<KI[]>([]); const [performance, setPerformance] = useState<PI[]>([])
  const [elementTextForAI, setElementTextForAI] = useState(''); const [loading, setLoading] = useState(false)
  useEffect(()=>{ if (!id || id==='new') return; (async()=>{ const t = (await api.get(`/templates/${id}`)).data; setName(t.name); setElement(t.element); setProficiency(t.proficiency); setVersion(t.version); setKnowledge(t.knowledge_items); setPerformance(t.performance_items) })() },[id])
  const addRow = (type:'K'|'P') => { const list = type==='K' ? [...knowledge] : [...performance]; const code = `${type} 1.${list.length}`; const row = { code, text:'', guidance:'' }; if (type==='K') setKnowledge(list.concat([row])); else setPerformance(list.concat([row])) }
  const save = async () => {
    setLoading(true); try { const payload = { name, element, proficiency, version, knowledge, performance }; const res = await api.post('/templates', payload); nav(`/templates/${res.data.id}`) } finally { setLoading(false) } }
  const aiDraft = async () => { const res = await api.post('/ai/draft/items', { element_text: elementTextForAI || element, proficiency, count_knowledge: 5, count_performance: 5 })
    setKnowledge((res.data.knowledge as string[]).map((t:string,i:number)=>({ code:`K 1.${i}`, text:t, guidance:res.data.assessor_guidance[i] || '' })))
    setPerformance((res.data.performance as string[]).map((t:string,i:number)=>({ code:`P 1.${i}`, text:t, guidance:res.data.assessor_guidance[i] || '' }))) }
  return (<div className="space-y-4">
    <h1 className="text-2xl font-bold">{id==='new' ? 'New Template' : 'Edit Template'}</h1>
    <div className="grid md:grid-cols-2 gap-4">
      <div className="space-y-2">
        <input className="w-full border p-2 rounded" placeholder="Template name" value={name} onChange={e=>setName(e.target.value)} />
        <input className="w-full border p-2 rounded" placeholder="Element (topic)" value={element} onChange={e=>setElement(e.target.value)} />
        <div className="flex gap-2">
          <select className="border p-2 rounded" value={proficiency} onChange={e=>setProficiency(e.target.value)}><option>Basic</option><option>Intermediate</option><option>Advanced</option></select>
          <input className="border p-2 rounded" placeholder="Version" value={version} onChange={e=>setVersion(e.target.value)} />
        </div>
        <div className="p-3 border rounded">
          <div className="text-sm font-semibold mb-2">AI Draft</div>
          <input className="w-full border p-2 rounded mb-2" placeholder="Element text for AI (optional)" value={elementTextForAI} onChange={e=>setElementTextForAI(e.target.value)} />
          <button onClick={aiDraft} className="px-3 py-1 rounded bg-black text-white text-sm">Generate items</button>
        </div>
      </div>
      <div className="space-y-2">
        <div className="flex items-center justify-between"><div className="font-semibold">Knowledge Items</div><button onClick={()=>addRow('K')} className="text-sm underline">Add</button></div>
        {knowledge.map((k,i)=>(<div key={i} className="p-2 border rounded"><div className="text-xs text-neutral-500 mb-1">{k.code}</div>
          <textarea className="w-full border p-2 rounded mb-2" rows={2} placeholder="Question text" value={k.text} onChange={e=>{ const c=[...knowledge]; c[i]={...c[i], text:e.target.value}; setKnowledge(c) }} />
          <input className="w-full border p-2 rounded" placeholder="Assessor guidance" value={k.guidance||''} onChange={e=>{ const c=[...knowledge]; c[i]={...c[i], guidance:e.target.value}; setKnowledge(c) }} /></div>))}
      </div>
    </div>
    <div className="space-y-2">
      <div className="flex items-center justify-between"><div className="font-semibold">Performance Items</div><button onClick={()=>addRow('P')} className="text-sm underline">Add</button></div>
      {performance.map((p,i)=>(<div key={i} className="p-2 border rounded"><div className="text-xs text-neutral-500 mb-1">{p.code}</div>
        <textarea className="w-full border p-2 rounded mb-2" rows={2} placeholder="Criteria text" value={p.text} onChange={e=>{ const c=[...performance]; c[i]={...c[i], text:e.target.value}; setPerformance(c) }} />
        <input className="w-full border p-2 rounded" placeholder="Assessor guidance" value={p.guidance||''} onChange={e=>{ const c=[...performance]; c[i]={...c[i], guidance:e.target.value}; setPerformance(c) }} /></div>))}
    </div>
    <div className="flex gap-2"><button onClick={save} disabled={loading} className="px-3 py-2 rounded bg-black text-white">{loading ? 'Saving...' : 'Save Template'}</button>
      <button onClick={()=>nav('/templates')} className="px-3 py-2 rounded border">Back</button></div>
  </div>)
}
