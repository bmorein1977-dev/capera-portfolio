import { useEffect, useState } from 'react'
import { api } from '../lib/api'
import SignaturePad from '../components/SignaturePad'
type Check = { id:number; assessment_id:number; verifier_user_id:number|null; status:string; result:string; notes:string }
export default function VerifierConsole() {
  const [queue, setQueue] = useState<Check[]>([])
  const [notes, setNotes] = useState<Record<number,string>>({})
  const [sig, setSig] = useState<Record<number,string|undefined>>({})
  const [nameV, setNameV] = useState<Record<number,string>>({})
  const load = async () => { const res = await api.get('/verification/queue'); setQueue(res.data) }
  useEffect(()=>{ load() }, [])
  const assign = async (id:number) => { await api.post(`/verification/assign/${id}`); load() }
  const finish = async (id:number, result:'OK'|'Issues') => {
    const n = notes[id] || ''
    await api.post(`/verification/finish/${id}`, null, { params: { result, notes: n } })
    if (sig[id]) { const aId = queue.find(q=>q.id===id)?.assessment_id; if (aId) await api.post(`/signatures/${aId}`, { role:'Verifier', name: nameV[id] || '', data_url: sig[id] }) }
    load()
  }
  return (<div className="space-y-4">
    <div className="flex items-center justify-between">
      <h1 className="text-2xl font-bold">Verification Queue</h1>
      <button onClick={async()=>{ await api.post('/verification/resample'); load() }} className="px-3 py-1 rounded bg-black text-white text-sm">Resample</button>
    </div>
    <ul className="space-y-2">{queue.map(c => (<li key={c.id} className="p-4 border rounded bg-white">
      <div className="text-sm">Assessment #{c.assessment_id}</div>
      <div className="text-xs text-neutral-600 mb-2">Status: {c.status} • Result: {c.result} • Verifier: {c.verifier_user_id ?? '—'}</div>
      <input className="w-full border p-2 rounded mb-2" placeholder="Verifier name (optional)" value={nameV[c.id] || ''} onChange={e=>setNameV({...nameV, [c.id]: e.target.value})} />
      <div className="mb-2"><SignaturePad onSave={(d)=>setSig({...sig, [c.id]: d})} /></div>
      <textarea className="w-full border p-2 rounded mb-2" rows={2} placeholder="Notes" value={notes[c.id] || ''} onChange={e=>setNotes({...notes, [c.id]: e.target.value})} />
      <div className="flex gap-2"><button onClick={()=>assign(c.id)} className="px-3 py-1 rounded border text-sm">Assign to me</button>
        <button onClick={()=>finish(c.id, 'OK')} className="px-3 py-1 rounded bg-green-600 text-white text-sm">Mark OK</button>
        <button onClick={()=>finish(c.id, 'Issues')} className="px-3 py-1 rounded bg-amber-600 text-white text-sm">Mark Issues</button></div>
    </li>))}</ul></div>)
}
