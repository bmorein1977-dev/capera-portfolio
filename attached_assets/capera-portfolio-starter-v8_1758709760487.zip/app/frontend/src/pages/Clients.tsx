import { useEffect, useState } from 'react'
import { api } from '../lib/api'

type Client = { id:number; name:string; logo_path?:string }

export default function Clients() {
  const [items, setItems] = useState<Client[]>([])
  const [name, setName] = useState('')
  const [file, setFile] = useState<File | null>(null)

  const load = async () => {
    const res = await api.get('/clients')
    setItems(res.data)
  }

  useEffect(()=>{ load() }, [])

  const create = async () => {
    if (!name) return
    await api.post('/clients', { name })
    setName('')
    await load()
  }

  const uploadLogo = async (id:number) => {
    if (!file) return
    const form = new FormData()
    form.append('file', file)
    await api.post(`/clients/${id}/logo`, form, { headers: { 'Content-Type':'multipart/form-data' } })
    setFile(null)
    await load()
  }

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Clients</h1>
      <div className="p-3 border rounded bg-white flex items-center gap-2">
        <input className="border p-2 rounded" placeholder="New client name" value={name} onChange={e=>setName(e.target.value)} />
        <button onClick={create} className="px-3 py-1 rounded bg-black text-white text-sm">Add</button>
      </div>
      <div className="space-y-2">
        {items.map(c => (
          <div key={c.id} className="p-3 border rounded bg-white">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-semibold">{c.name}</div>
                {c.logo_path && <img src={`${api.defaults.baseURL}${c.logo_path}`} alt="logo" className="h-10 mt-1" />}
              </div>
              <div className="flex items-center gap-2">
                <input type="file" accept="image/*" onChange={e=>setFile(e.target.files?.[0] || null)} />
                <button onClick={()=>uploadLogo(c.id)} className="px-3 py-1 rounded border text-sm" disabled={!file}>Upload Logo</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
