import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { api } from '../lib/api'
import { useAuth } from '../lib/auth'
export default function Login() {
  const [email, setEmail] = useState(''); const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false); const [error, setError] = useState<string | null>(null)
  const nav = useNavigate(); const { setUser } = useAuth()
  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault(); setLoading(true); setError(null)
    try {
      const res = await api.post('/auth/login', { email, password })
      localStorage.setItem('token', res.data.access_token)
      const me = await api.get('/auth/me'); setUser(me.data); nav('/dashboard')
    } catch (err:any) { setError(err?.response?.data?.detail || 'Login failed') } finally { setLoading(false) }
  }
  return (<div className="max-w-sm mx-auto">
    <h1 className="text-2xl font-bold mb-4">Sign in</h1>
    <form onSubmit={onSubmit} className="space-y-3">
      <input className="w-full border p-2 rounded" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
      <input className="w-full border p-2 rounded" placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
      {error && <p className="text-sm text-red-600">{error}</p>}
      <button disabled={loading} className="w-full p-2 rounded bg-black text-white">{loading ? '...' : 'Sign in'}</button>
    </form>
    <p className="text-xs text-neutral-600 mt-4">No account? <Link to="/register" className="underline">Create one</Link></p>
  </div>)
}
