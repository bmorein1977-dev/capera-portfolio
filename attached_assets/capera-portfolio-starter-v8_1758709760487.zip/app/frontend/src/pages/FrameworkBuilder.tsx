import { useEffect, useState } from 'react'
import { api } from '../lib/api'
export default function FrameworkBuilder() {
  const [cats, setCats] = useState<any[]>([]); const [loading, setLoading] = useState(true)
  useEffect(() => { (async()=>{ const res = await api.get('/framework/categories'); setCats(res.data); setLoading(false) })() }, [])
  return (<div className="space-y-4"><h1 className="text-2xl font-bold">Framework Builder</h1>
    {loading ? <p>Loading...</p> : (
      <div className="grid md:grid-cols-2 gap-3">
        {cats.map(c => (<div key={c.id} className="p-4 border rounded bg-white">
          <div className="font-semibold">{c.code} — {c.name}</div><div className="text-sm text-neutral-600">{c.description}</div>
        </div>))}
      </div>
    )}</div>)
}
