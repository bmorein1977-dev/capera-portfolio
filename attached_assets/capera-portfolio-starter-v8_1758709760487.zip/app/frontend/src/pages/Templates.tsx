import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { api } from '../lib/api'
type Template = { id:number; name:string; element:string; proficiency:string; version:string }
export default function Templates() {
  const [items, setItems] = useState<Template[]>([]); const [loading, setLoading] = useState(true)
  useEffect(()=>{ (async()=>{ const res = await api.get('/templates'); setItems(res.data); setLoading(false) })() }, [])
  return (<div className="space-y-4">
    <div className="flex items-center justify-between"><h1 className="text-2xl font-bold">Templates</h1><Link to="/templates/new" className="px-3 py-1 rounded bg-black text-white text-sm">New Template</Link>
        <a href="/templates/import" className="px-3 py-1 rounded border text-sm">Import CSV</a></div>
    {loading ? <p>Loading...</p> : <ul className="space-y-2">{items.map(t => (<li key={t.id} className="p-4 border rounded bg-white flex items-center justify-between">
      <div><div className="font-semibold">{t.name}</div><div className="text-sm text-neutral-600">{t.element} — {t.proficiency} (v{t.version})</div></div>
      <Link to={`/templates/${t.id}`} className="text-sm underline">Open</Link></li>))}</ul>}
  </div>)
}
