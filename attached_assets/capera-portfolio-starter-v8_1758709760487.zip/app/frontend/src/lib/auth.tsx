import { createContext, useContext, useEffect, useState } from 'react'
import { api } from './api'
type User = { id: number; email: string; role: string; locale: string; first_name?: string; last_name?: string }
type Ctx = { user: User | null; setUser: (u: User | null) => void; logout: () => void }
const AuthCtx = createContext<Ctx>({ user: null, setUser: () => {}, logout: () => {} })
export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  useEffect(() => { const t = localStorage.getItem('token'); if (t) api.get('/auth/me').then(r=>setUser(r.data)).catch(()=>setUser(null)) }, [])
  const logout = () => { localStorage.removeItem('token'); setUser(null); window.location.href = '/login' }
  return <AuthCtx.Provider value={{ user, setUser, logout }}>{children}</AuthCtx.Provider>
}
export const useAuth = () => useContext(AuthCtx)
