import Dexie, { Table } from 'dexie'
export interface Evidence { id?: number; filename: string; blob: Blob; notes?: string; created_at: number }
class CaperaDB extends Dexie {
  evidence!: Table<Evidence, number>; queue!: Table<any, number>
  constructor(){ super('capera-db'); this.version(1).stores({ evidence: '++id, filename, created_at', queue: '++id, created_at' }) }
}
export const db = new CaperaDB()
