from fastapi import Depends, HTTPException, status
from app.dependencies import get_current_user

def require_roles(*roles):
    def checker(user = Depends(get_current_user)):
        if user.role not in roles and user.role != "Admin":
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Insufficient role")
        return user
    return checker
