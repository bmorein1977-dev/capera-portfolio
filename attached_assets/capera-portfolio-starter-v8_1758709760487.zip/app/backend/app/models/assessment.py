from sqlalchemy import Integer, String, ForeignKey, Text, DateTime
from sqlalchemy.sql import func
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db import Base

class Assessment(Base):
    __tablename__ = "assessments"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    candidate_name: Mapped[str] = mapped_column(String(255))
    template_id: Mapped[int] = mapped_column(Integer)  # FK simplified
    assessor_user_id: Mapped[int] = mapped_column(Integer)
    client_id: Mapped[int] = mapped_column(Integer, nullable=True)
    status: Mapped[str] = mapped_column(String(32), default="In-Progress")  # In-Progress/Submitted/Closed
    outcome: Mapped[str] = mapped_column(String(32), default="Undecided")   # Competent/SkillsGap/NA/Undecided
    closed_at: Mapped[DateTime] = mapped_column(DateTime, nullable=True)
    closed_by_user_id: Mapped[int] = mapped_column(Integer, nullable=True)

    lines = relationship("AssessmentLine", back_populates="assessment", cascade="all, delete-orphan")

class AssessmentLine(Base):
    __tablename__ = "assessment_lines"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    assessment_id: Mapped[int] = mapped_column(Integer)  # FK simplified
    item_type: Mapped[str] = mapped_column(String(16))  # Knowledge | Performance
    item_code: Mapped[str] = mapped_column(String(32))
    item_text: Mapped[str] = mapped_column(Text)
    outcome: Mapped[str] = mapped_column(String(8), default="NA")  # C | SG | NA
    comments: Mapped[str] = mapped_column(Text, default="")

    assessment = relationship("Assessment", back_populates="lines")
