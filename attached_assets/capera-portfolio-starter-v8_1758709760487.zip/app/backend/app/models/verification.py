from sqlalchemy import Integer, String, Float, DateTime
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.sql import func
from app.db import Base

class SamplingPolicy(Base):
    __tablename__ = "sampling_policies"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    assessor_user_id: Mapped[int] = mapped_column(Integer)
    rate_percent: Mapped[float] = mapped_column(Float, default=20.0)

class VerificationCheck(Base):
    __tablename__ = "verification_checks"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    assessment_id: Mapped[int] = mapped_column(Integer)
    verifier_user_id: Mapped[int] = mapped_column(Integer, nullable=True)
    status: Mapped[str] = mapped_column(String(24), default="Queued")  # Queued/In-Review/Done
    result: Mapped[str] = mapped_column(String(24), default="Pending") # OK/Issues/Pending
    notes: Mapped[str] = mapped_column(String(1000), default="")
    created_at: Mapped[DateTime] = mapped_column(DateTime, server_default=func.now())
    updated_at: Mapped[DateTime] = mapped_column(DateTime, server_default=func.now(), onupdate=func.now())
