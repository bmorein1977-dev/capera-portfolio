from sqlalchemy import Integer, String, ForeignKey, Text, Boolean
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db import Base

class Template(Base):
    __tablename__ = "templates"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255))
    element: Mapped[str] = mapped_column(String(255))
    proficiency: Mapped[str] = mapped_column(String(32), default="Basic")
    version: Mapped[str] = mapped_column(String(32), default="1.0")

    knowledge_items = relationship("KnowledgeItem", back_populates="template", cascade="all, delete-orphan")
    performance_items = relationship("PerformanceItem", back_populates="template", cascade="all, delete-orphan")

class KnowledgeItem(Base):
    __tablename__ = "knowledge_items"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    template_id: Mapped[int] = mapped_column(ForeignKey("templates.id"))
    code: Mapped[str] = mapped_column(String(32))
    text: Mapped[str] = mapped_column(Text)
    guidance: Mapped[str] = mapped_column(Text, default="")
    is_optional: Mapped[bool] = mapped_column(Boolean, default=False)
    weight: Mapped[int] = mapped_column(Integer, default=1)
    template = relationship("Template", back_populates="knowledge_items")

class PerformanceItem(Base):
    __tablename__ = "performance_items"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    template_id: Mapped[int] = mapped_column(ForeignKey("templates.id"))
    code: Mapped[str] = mapped_column(String(32))
    text: Mapped[str] = mapped_column(Text)
    guidance: Mapped[str] = mapped_column(Text, default="")
    is_optional: Mapped[bool] = mapped_column(Boolean, default=False)
    weight: Mapped[int] = mapped_column(Integer, default=1)
    template = relationship("Template", back_populates="performance_items")
