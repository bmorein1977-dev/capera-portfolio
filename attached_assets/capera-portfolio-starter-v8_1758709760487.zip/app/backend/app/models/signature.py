from sqlalchemy import Integer, String, DateTime
from sqlalchemy.sql import func
from sqlalchemy.orm import Mapped, mapped_column
from app.db import Base

class Signature(Base):
    __tablename__ = "signatures"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    assessment_id: Mapped[int] = mapped_column(Integer)
    role: Mapped[str] = mapped_column(String(16))        # Assessor | Candidate | Verifier
    name: Mapped[str] = mapped_column(String(255), default="")
    image_path: Mapped[str] = mapped_column(String(512)) # /files/signatures/*
    signed_at: Mapped[DateTime] = mapped_column(DateTime, server_default=func.now())
