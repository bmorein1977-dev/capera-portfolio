from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from datetime import datetime
from app.db import get_db
from app.models.assessment import Assessment, AssessmentLine
from app.models.template import Template
from app.schemas.assessment import AssessmentCreate, AssessmentOut, LineUpdate
from app.dependencies_roles import require_roles
from app.dependencies import get_current_user

router = APIRouter()

@router.get("", response_model=List[AssessmentOut])
def list_assessments(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return db.query(Assessment).order_by(Assessment.id.desc()).all()

@router.post("", response_model=AssessmentOut)
def create_assessment(payload: AssessmentCreate, db: Session = Depends(get_db), user=Depends(require_roles('Assessor','Admin'))):
    t = db.query(Template).get(payload.template_id)
    if not t: raise HTTPException(404, "Template not found")
    a = Assessment(candidate_name=payload.candidate_name, template_id=t.id, assessor_user_id=user.id, client_id=payload.client_id, status="In-Progress", outcome="Undecided")
    db.add(a); db.flush()
    for ki in t.knowledge_items:
        db.add(AssessmentLine(assessment_id=a.id, item_type="Knowledge", item_code=ki.code, item_text=ki.text, outcome="NA"))
    for pi in t.performance_items:
        db.add(AssessmentLine(assessment_id=a.id, item_type="Performance", item_code=pi.code, item_text=pi.text, outcome="NA"))
    db.commit(); db.refresh(a); return a

@router.get("/{assessment_id}")
def get_assessment(assessment_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    a = db.query(Assessment).get(assessment_id)
    if not a: raise HTTPException(404, "Not found")
    lines = db.query(AssessmentLine).filter(AssessmentLine.assessment_id == a.id).order_by(AssessmentLine.id).all()
    return {"id": a.id, "candidate_name": a.candidate_name, "template_id": a.template_id, "status": a.status, "outcome": a.outcome,
            "lines": [{"id": l.id, "item_type": l.item_type, "item_code": l.item_code, "item_text": l.item_text, "outcome": l.outcome, "comments": l.comments} for l in lines]}

@router.post("/{assessment_id}/lines")
def update_lines(assessment_id: int, updates: List[LineUpdate], db: Session = Depends(get_db), user=Depends(require_roles('Assessor','Admin'))):
    a = db.query(Assessment).get(assessment_id)
    if not a: raise HTTPException(404, "Not found")
    for u in updates:
        l = db.query(AssessmentLine).get(u.id)
        if not l or l.assessment_id != assessment_id: raise HTTPException(404, f"Line {u.id} not found")
        l.outcome = u.outcome; l.comments = u.comments or ""
    db.commit(); return {"status":"ok"}

@router.post("/{assessment_id}/submit")
def submit_assessment(assessment_id: int, db: Session = Depends(get_db), user=Depends(require_roles('Assessor','Admin'))):
    a = db.query(Assessment).get(assessment_id)
    if not a: raise HTTPException(404, "Not found")
    a.status = "Submitted"; db.commit()
    return {"status":"submitted", "outcome": a.outcome}

@router.post("/{assessment_id}/close")
def close_assessment(assessment_id: int, db: Session = Depends(get_db), user=Depends(require_roles('Assessor','Admin'))):
    a = db.query(Assessment).get(assessment_id)
    if not a: raise HTTPException(404, "Not found")
    lines = db.query(AssessmentLine).filter(AssessmentLine.assessment_id == a.id).all()
    outcomes = [l.outcome for l in lines]
    if any(o == "SG" for o in outcomes): a.outcome = "SkillsGap"
    elif outcomes and all(o == "C" for o in outcomes): a.outcome = "Competent"
    else: a.outcome = "Undecided"
    a.status = "Closed"; a.closed_at = datetime.utcnow(); a.closed_by_user_id = user.id
    db.commit()
    # enqueue QA (non-blocking)
    try:
        from app.models.verification import SamplingPolicy, VerificationCheck
        pol = db.query(SamplingPolicy).filter(SamplingPolicy.assessor_user_id == a.assessor_user_id).first()
        rate = pol.rate_percent if pol else 20.0
        import random
        if random.random() < (rate/100.0):
            db.add(VerificationCheck(assessment_id=a.id, status="Queued", result="Pending")); db.commit()
    except Exception: pass
    return {"status":"closed", "outcome": a.outcome}
