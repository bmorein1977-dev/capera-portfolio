from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List
from app.db import get_db
from app.models.category import Category as CategoryModel
from pydantic import BaseModel

router = APIRouter()

class Category(BaseModel):
    id: int; code: str; name: str; description: str | None = None; safety_criticality: str | None = None
    class Config: from_attributes = True

@router.get("/categories", response_model=List[Category])
def list_categories(db: Session = Depends(get_db)):
    return db.query(CategoryModel).order_by(CategoryModel.code).all()
