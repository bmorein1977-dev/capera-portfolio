import os
from fastapi import APIRouter, UploadFile, File
from app.core.config import settings
router = APIRouter()
@router.post("/upload")
async def upload(file: UploadFile = File(...)):
    os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
    dest = os.path.join(settings.UPLOAD_DIR, file.filename)
    with open(dest, "wb") as f:
        while True:
            chunk = await file.read(1024*1024)
            if not chunk: break
            f.write(chunk)
    return {"filename": file.filename, "url": f"/files/{file.filename}"}
