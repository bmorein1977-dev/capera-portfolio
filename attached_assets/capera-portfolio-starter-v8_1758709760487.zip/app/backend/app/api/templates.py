from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from app.db import get_db
from app.models.template import Template, KnowledgeItem, PerformanceItem
from app.schemas.template import TemplateCreate, TemplateOut
from app.dependencies import get_current_user

router = APIRouter()

@router.get("", response_model=List[TemplateOut])
def list_templates(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return db.query(Template).order_by(Template.id.desc()).all()

@router.post("", response_model=TemplateOut)
def create_template(payload: TemplateCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    t = Template(name=payload.name, element=payload.element, proficiency=payload.proficiency, version=payload.version)
    db.add(t); db.flush()
    for k in payload.knowledge:
        db.add(KnowledgeItem(template_id=t.id, code=k.code, text=k.text, guidance=k.guidance, is_optional=k.is_optional, weight=k.weight))
    for p in payload.performance:
        db.add(PerformanceItem(template_id=t.id, code=p.code, text=p.text, guidance=p.guidance, is_optional=p.is_optional, weight=p.weight))
    db.commit(); db.refresh(t); return t

@router.get("/{template_id}")
def get_template(template_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    t = db.query(Template).get(template_id)
    if not t: raise HTTPException(404, "Template not found")
    return {
        "id": t.id, "name": t.name, "element": t.element, "proficiency": t.proficiency, "version": t.version,
        "knowledge_items": [{"code": x.code, "text": x.text, "guidance": x.guidance, "is_optional": x.is_optional, "weight": x.weight} for x in t.knowledge_items],
        "performance_items": [{"code": x.code, "text": x.text, "guidance": x.guidance, "is_optional": x.is_optional, "weight": x.weight} for x in t.performance_items],
    }
