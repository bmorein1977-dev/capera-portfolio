from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db import get_db
from app.models.verification import SamplingPolicy, VerificationCheck
from app.models.assessment import Assessment
from app.dependencies_roles import require_roles
from app.dependencies import get_current_user

router = APIRouter()

@router.get("/policies")
def list_policies(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return db.query(SamplingPolicy).all()

@router.post("/policies")
def set_policy(assessor_user_id: int, rate_percent: float, db: Session = Depends(get_db), user=Depends(require_roles('Admin'))):
    pol = db.query(SamplingPolicy).filter(SamplingPolicy.assessor_user_id == assessor_user_id).first()
    if pol: pol.rate_percent = rate_percent
    else: db.add(SamplingPolicy(assessor_user_id=assessor_user_id, rate_percent=rate_percent))
    db.commit()
    return db.query(SamplingPolicy).filter(SamplingPolicy.assessor_user_id == assessor_user_id).first()

@router.get("/queue")
def queue(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return db.query(VerificationCheck).order_by(VerificationCheck.id.desc()).all()

@router.post("/assign/{check_id}")
def assign(check_id: int, db: Session = Depends(get_db), user=Depends(require_roles('Verifier','Admin'))):
    vc = db.query(VerificationCheck).get(check_id)
    if not vc: raise HTTPException(404, "Check not found")
    vc.verifier_user_id = user.id; vc.status = "In-Review"; db.commit(); return vc

@router.post("/finish/{check_id}")
def finish(check_id: int, result: str, notes: str = "", db: Session = Depends(get_db), user=Depends(require_roles('Verifier','Admin'))):
    if result not in ("OK","Issues"): raise HTTPException(400, "Invalid result")
    vc = db.query(VerificationCheck).get(check_id)
    if not vc: raise HTTPException(404, "Check not found")
    vc.result = result; vc.notes = notes; vc.status = "Done"; db.commit(); return vc

@router.post("/resample")
def resample(db: Session = Depends(get_db), user=Depends(require_roles('Admin'))):
    policies = {p.assessor_user_id: p.rate_percent for p in db.query(SamplingPolicy).all()}
    submitted = db.query(Assessment).filter(Assessment.status == "Submitted").all()
    created = 0
    import random
    for a in submitted:
        if db.query(VerificationCheck).filter(VerificationCheck.assessment_id == a.id).first(): continue
        rate = policies.get(a.assessor_user_id, 20.0)
        if random.random() < (rate/100.0):
            db.add(VerificationCheck(assessment_id=a.id, status="Queued", result="Pending")); created += 1
    db.commit(); return {"created": created}
