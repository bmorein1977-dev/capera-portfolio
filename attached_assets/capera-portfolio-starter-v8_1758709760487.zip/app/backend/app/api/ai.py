from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class DraftItemsReq(BaseModel):
    element_text: str
    proficiency: str = "Basic"
    count_knowledge: int = 5
    count_performance: int = 5

@router.post("/draft/items")
def draft_items(req: DraftItemsReq):
    k = [f"Explain the concept #{i+1} related to: {req.element_text}" for i in range(req.count_knowledge)]
    p = [f"Demonstrate task #{i+1} safely for: {req.element_text}" for i in range(req.count_performance)]
    guidance = [f"Assessor checks clarity, accuracy, safety (stub {i+1})." for i in range(max(req.count_knowledge, req.count_performance))]
    return {"knowledge": k, "performance": p, "assessor_guidance": guidance}
