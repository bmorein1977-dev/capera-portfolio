from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.db import get_db
from app.models.user import User
from app.schemas.auth import UserCreate, LoginReq, Token, UserOut
from app.core.security import verify_password, get_password_hash, create_access_token
from app.dependencies import get_current_user

router = APIRouter()

@router.post("/register", response_model=UserOut)
def register(payload: UserCreate, db: Session = Depends(get_db)):
    if db.query(User).filter(User.email == payload.email).first():
        raise HTTPException(status_code=400, detail="Email already registered")
    u = User(email=payload.email, hashed_password=get_password_hash(payload.password),
             first_name=payload.first_name or "", last_name=payload.last_name or "",
             role=payload.role, locale=payload.locale)
    db.add(u); db.commit(); db.refresh(u); return u

@router.post("/login", response_model=Token)
def login(payload: LoginReq, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == payload.email).first()
    if not user or not verify_password(payload.password, user.hashed_password):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
    return {"access_token": create_access_token(user.id), "token_type": "bearer"}

@router.get("/me", response_model=UserOut)
def me(current_user: User = Depends(get_current_user)): return current_user
