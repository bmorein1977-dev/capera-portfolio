import os, base64, re
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from app.db import get_db
from app.core.config import settings
from app.models.signature import Signature
from app.dependencies import get_current_user

router = APIRouter()

class SignReq(BaseModel):
    role: str  # Assessor | Candidate | Verifier
    name: str = ""
    data_url: str  # data:image/png;base64,...

@router.post("/{assessment_id}")
def sign(assessment_id: int, payload: SignReq, db: Session = Depends(get_db), user=Depends(get_current_user)):
    if payload.role not in ("Assessor","Candidate","Verifier"):
        raise HTTPException(status_code=400, detail="Invalid role")
    m = re.match(r'^data:image/(png|jpeg);base64,(.+)$', payload.data_url)
    if not m: raise HTTPException(status_code=400, detail="Invalid image data")
    ext, b64 = m.groups()
    data = base64.b64decode(b64.encode("utf-8"))
    out_dir = os.path.join(settings.UPLOAD_DIR, "signatures"); os.makedirs(out_dir, exist_ok=True)
    filename = f"sign_{assessment_id}_{payload.role.lower()}.{ 'png' if ext=='png' else 'jpg' }"
    path = os.path.join(out_dir, filename)
    with open(path, "wb") as f: f.write(data)
    s = Signature(assessment_id=assessment_id, role=payload.role, name=payload.name or "", image_path=f"/files/signatures/{filename}")
    db.add(s); db.commit(); db.refresh(s)
    return {"id": s.id, "image_url": s.image_path, "name": s.name, "role": s.role}
