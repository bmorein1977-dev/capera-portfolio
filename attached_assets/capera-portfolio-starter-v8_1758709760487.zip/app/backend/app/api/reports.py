from fastapi import APIRouter, Depends, Response
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.db import get_db
from app.models.assessment import Assessment, AssessmentLine
from app.models.template import Template
from app.models.client import Client
from app.dependencies import get_current_user
import csv, io

router = APIRouter()

@router.get("/skills-gaps")
def skills_gaps(db: Session = Depends(get_db), user=Depends(get_current_user)):
    rows = db.query(
        Assessment.candidate_name,
        func.sum(func.case((AssessmentLine.outcome=="SG", 1), else_=0)).label("sg"),
        func.sum(func.case((AssessmentLine.outcome=="C", 1), else_=0)).label("c"),
        func.sum(func.case((AssessmentLine.outcome=="NA", 1), else_=0)).label("na"),
        func.count(AssessmentLine.id).label("total")
    ).join(AssessmentLine, Assessment.id == AssessmentLine.assessment_id).group_by(Assessment.candidate_name).all()
    return [{"candidate": r[0], "skills_gap": int(r[1]), "competent": int(r[2]), "not_applicable": int(r[3]), "total": int(r[4])} for r in rows]

@router.get("/skills-heatmap")
def skills_heatmap(db: Session = Depends(get_db), user=Depends(get_current_user)):
    q = db.query(
        Assessment.candidate_name.label("candidate"),
        Template.element.label("element"),
        func.sum(func.case((AssessmentLine.outcome=="SG", 1), else_=0)).label("sg")
    ).join(AssessmentLine, Assessment.id == AssessmentLine.assessment_id).join(Template, Template.id == Assessment.template_id).group_by(Assessment.candidate_name, Template.element).all()
    candidates = sorted({r[0] for r in q}); elements = sorted({r[1] for r in q})
    values = {(r[0], r[1]): int(r[2]) for r in q}
    matrix = [[values.get((c,e), 0) for e in elements] for c in candidates]
    return {"candidates": candidates, "elements": elements, "matrix": matrix}

@router.get("/skills-gaps.csv")
def skills_gaps_csv(db: Session = Depends(get_db), user=Depends(get_current_user)):
    data = skills_gaps(db, user)
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=["candidate","skills_gap","competent","not_applicable","total"])
    writer.writeheader()
    for row in data: writer.writerow(row)
    return Response(content=output.getvalue(), media_type="text/csv", headers={"Content-Disposition":"attachment; filename=skills-gaps.csv"})

@router.get("/skills-gaps.pdf")
def skills_gaps_pdf(client_id: int | None = None, db: Session = Depends(get_db), user=Depends(get_current_user)):
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    from reportlab.lib.units import cm
    data = skills_gaps(db, user)
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    width, height = A4; y = height - 2*cm
    c.setFont("Helvetica-Bold", 14); c.drawString(2*cm, y, "Skills Gaps Report")
    if client_id:
        client = db.query(Client).get(client_id)
        if client and client.logo_path:
            try:
                from reportlab.lib.utils import ImageReader
                img = ImageReader("." + client.logo_path if client.logo_path.startswith("/") else client.logo_path)
                c.drawImage(img, 13*cm, y-0.3*cm, width=4*cm, height=1.2*cm, preserveAspectRatio=True, mask='auto')
            except Exception:
                pass
    y -= 1*cm
    c.setFont("Helvetica", 10)
    headers = ["Candidate","Skills Gap","Competent","N/A","Total"]; x0 = [2*cm, 9*cm, 12*cm, 14*cm, 16*cm]
    for i, h in enumerate(headers): c.drawString(x0[i], y, h)
    y -= 0.5*cm
    for row in data:
        vals = [row["candidate"], str(row["skills_gap"]), str(row["competent"]), str(row["not_applicable"]), str(row["total"])]
        for i, v in enumerate(vals): c.drawString(x0[i], y, v[:30])
        y -= 0.5*cm
        if y < 2*cm: c.showPage(); y = height - 2*cm
    c.showPage(); c.save()
    pdf = buf.getvalue(); buf.close()
    return Response(content=pdf, media_type="application/pdf", headers={"Content-Disposition":"attachment; filename=skills-gaps.pdf"})


@router.get("/skills-gaps.xlsx")
def skills_gaps_xlsx(client_id: int | None = None, db: Session = Depends(get_db), user=Depends(get_current_user)):
    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
    from openpyxl.drawing.image import Image as XLImage
    from app.models.client import Client
    import os

    data = skills_gaps(db, user)
    wb = Workbook()
    ws = wb.active
    ws.title = "Skills Gaps"

    row = 1
    # Optional logo
    if client_id:
        client = db.query(Client).get(client_id)
        if client and client.logo_path:
            path = "." + client.logo_path if client.logo_path.startswith("/") else client.logo_path
            if os.path.exists(path):
                try:
                    img = XLImage(path)
                    img.width = 220  # px
                    img.height = 60
                    ws.add_image(img, "E1")
                except Exception:
                    pass
            # Client name/title
            ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=4)
            ws.cell(row=row, column=1, value=f"Skills Gaps Report — {client.name}").font = Font(bold=True, size=14)
            row += 2
    else:
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=4)
        ws.cell(row=row, column=1, value=f"Skills Gaps Report").font = Font(bold=True, size=14)
        row += 2

    # Header row
    headers = ["Candidate","Skills Gap","Competent","N/A","Total"]
    for c, h in enumerate(headers, start=1):
        cell = ws.cell(row=row, column=c, value=h)
        cell.font = Font(bold=True)
        cell.alignment = Alignment(horizontal="center")
        cell.fill = PatternFill("solid", fgColor="EEECE7")
    row += 1

    # Data rows
    thin = Side(style="thin", color="CCCCCC")
    border = Border(top=thin, left=thin, right=thin, bottom=thin)
    for r in data:
        vals = [r["candidate"], r["skills_gap"], r["competent"], r["not_applicable"], r["total"]]
        for c, v in enumerate(vals, start=1):
            cell = ws.cell(row=row, column=c, value=v)
            cell.border = border
        row += 1

    # Column widths
    ws.column_dimensions["A"].width = 28
    for col in "BCDE":
        ws.column_dimensions[col].width = 14

    # Serialize
    import io
    bio = io.BytesIO()
    wb.save(bio)
    return Response(content=bio.getvalue(), media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition":"attachment; filename=skills-gaps.xlsx"})
