from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from sqlalchemy.orm import Session
import os
from typing import List
from pydantic import BaseModel
from app.db import get_db
from app.models.client import Client
from app.core.config import settings
from app.dependencies_roles import require_roles
from app.dependencies import get_current_user

router = APIRouter()

class ClientIn(BaseModel):
    name: str

@router.get("", response_model=List[ClientIn])
def list_clients(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return db.query(Client).order_by(Client.name).all()

@router.post("")
def create_client(payload: ClientIn, db: Session = Depends(get_db), user=Depends(require_roles('Admin'))):
    if db.query(Client).filter(Client.name == payload.name).first():
        raise HTTPException(400, "Client with that name exists")
    c = Client(name=payload.name); db.add(c); db.commit(); db.refresh(c); return c

@router.post("/{client_id}/logo")
async def upload_logo(client_id: int, file: UploadFile = File(...), db: Session = Depends(get_db), user=Depends(require_roles('Admin'))):
    c = db.query(Client).get(client_id)
    if not c: raise HTTPException(404, "Client not found")
    os.makedirs(f"{settings.UPLOAD_DIR}/logos", exist_ok=True)
    ext = os.path.splitext(file.filename)[1] or ".png"
    filename = f"client_{client_id}{ext}"
    dest = os.path.join(settings.UPLOAD_DIR, "logos", filename)
    with open(dest, "wb") as f:
        while True:
            chunk = await file.read(1024*1024)
            if not chunk: break
            f.write(chunk)
    c.logo_path = f"/files/logos/{filename}"
    db.commit(); db.refresh(c)
    return {"id": c.id, "name": c.name, "logo_path": c.logo_path}
