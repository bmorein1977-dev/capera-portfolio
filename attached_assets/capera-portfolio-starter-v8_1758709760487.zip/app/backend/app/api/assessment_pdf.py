from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from fastapi.responses import Response
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import cm
from reportlab.lib.utils import ImageReader

from app.db import get_db
from app.models.assessment import Assessment, AssessmentLine
from app.models.template import Template
from app.models.signature import Signature
from app.models.client import Client
from app.dependencies import get_current_user

router = APIRouter()

@router.get("/{assessment_id}.pdf")
def assessment_pdf(assessment_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    a = db.query(Assessment).get(assessment_id)
    if not a: raise HTTPException(404, "Assessment not found")
    tmpl = db.query(Template).get(a.template_id)
    client = db.query(Client).get(a.client_id) if a.client_id else None

    sigs = db.query(Signature).filter(Signature.assessment_id == assessment_id).all()
    sig_map = {}
    for s in sigs:
        sig_map.setdefault(s.role, []).append(s)

    lines = db.query(AssessmentLine).filter(AssessmentLine.assessment_id == a.id).order_by(AssessmentLine.id).all()

    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    width, height = A4
    y = height - 2*cm

    # Header
    c.setFont("Helvetica-Bold", 16)
    c.drawString(2*cm, y, "Assessment Summary")
    # draw logo if available
    if client and client.logo_path:
        try:
            from reportlab.lib.utils import ImageReader
            img = ImageReader("." + client.logo_path if client.logo_path.startswith("/") else client.logo_path)
            c.drawImage(img, 12*cm, y-0.2*cm, width=5*cm, height=1.5*cm, preserveAspectRatio=True, mask='auto')
        except Exception:
            pass
    y -= 0.7*cm
    c.setFont("Helvetica", 10)
    c.drawString(2*cm, y, f"Candidate: {a.candidate_name}")
    c.drawRightString(width-2*cm, y, f"Outcome: {a.outcome}")
    y -= 0.5*cm
    c.drawString(2*cm, y, f"Template: {tmpl.name if tmpl else a.template_id} — {tmpl.element if tmpl else ''}")
    c.drawRightString(width-2*cm, y, f"Status: {a.status}")
    y -= 0.7*cm

    # Lines table
    c.setFont("Helvetica-Bold", 11)
    c.drawString(2*cm, y, "Items"); y -= 0.5*cm
    c.setFont("Helvetica", 9)
    for l in lines:
        txt = f"{l.item_type[0]} {l.item_code}: {l.item_text}"
        chunk = 95
        # wrap item text roughly
        while txt:
            line = txt[:chunk]; txt = txt[chunk:]
            c.drawString(2*cm, y, line)
            y -= 0.4*cm
            if y < 5*cm:
                c.showPage(); y = height - 2*cm
        c.drawRightString(width-2*cm, y+0.2*cm, f"{l.outcome}")
        if l.comments:
            c.setFont("Helvetica-Oblique", 8)
            c.drawString(2.5*cm, y, f"Notes: {l.comments[:150]}")
            c.setFont("Helvetica", 9)
            y -= 0.4*cm
        y -= 0.1*cm
        if y < 5*cm:
            c.showPage(); y = height - 2*cm

    # Signatures section
    if y < 4*cm:
        c.showPage(); y = height - 2*cm
    c.setFont("Helvetica-Bold", 11)
    c.drawString(2*cm, y, "Signatures (optional)")
    y -= 0.6*cm
    roles = ["Assessor", "Candidate", "Verifier"]
    for role in roles:
        c.setFont("Helvetica-Bold", 9); c.drawString(2*cm, y, role + ":"); c.setFont("Helvetica", 9)
        y -= 0.4*cm
        imgs = sig_map.get(role, [])
        if not imgs:
            c.drawString(2.5*cm, y, "—"); y -= 0.6*cm
        else:
            x = 2.5*cm
            for s in imgs:
                try:
                    img = ImageReader("." + s.image_path if s.image_path.startswith("/") else s.image_path)
                    c.drawImage(img, x, y-2*cm, width=5*cm, height=2*cm, preserveAspectRatio=True, mask='auto')
                    c.drawString(x, y-2.2*cm, s.name or "")
                    x += 6*cm
                except Exception:
                    c.drawString(x, y, "(signature image missing)"); x += 6*cm
            y -= 2.6*cm
        if y < 3*cm:
            c.showPage(); y = height - 2*cm

    c.showPage(); c.save()
    pdf = buf.getvalue(); buf.close()
    return Response(content=pdf, media_type="application/pdf", headers={"Content-Disposition": f"attachment; filename=assessment-{assessment_id}.pdf"})
