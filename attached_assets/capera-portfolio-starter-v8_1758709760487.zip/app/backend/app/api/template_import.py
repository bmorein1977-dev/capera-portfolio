from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from sqlalchemy.orm import Session
import csv, io
from app.db import get_db
from app.models.template import Template, KnowledgeItem, PerformanceItem
from app.dependencies_roles import require_roles

router = APIRouter()

# CSV columns: name,element,proficiency,version,type,code,text,guidance,is_optional,weight
@router.post("/bulk_csv")
async def bulk_csv(file: UploadFile = File(...), db: Session = Depends(get_db), user=Depends(require_roles('Admin','Assessor'))):
    content = await file.read()
    try:
        s = content.decode("utf-8")
    except Exception:
        raise HTTPException(400, "CSV must be UTF-8")
    rdr = csv.DictReader(io.StringIO(s))
    groups = {}
    for row in rdr:
        key = (row.get("name","").strip(), row.get("version","1.0").strip())
        if not key[0]:
            raise HTTPException(400, "Each row must include name")
        groups.setdefault(key, {"name": row.get("name","").strip(), "element": row.get("element","").strip(), "proficiency": row.get("proficiency","Basic").strip(), "version": row.get("version","1.0").strip(), "K": [], "P": []})
        typ = (row.get("type") or "").strip().upper()
        if typ not in ("K","P"):
            raise HTTPException(400, "type must be K or P")
        item = {
            "code": row.get("code","").strip(),
            "text": row.get("text","").strip(),
            "guidance": row.get("guidance","").strip(),
            "is_optional": (row.get("is_optional","").strip().lower() in ("1","true","yes","y")),
            "weight": int(row.get("weight","1").strip() or "1"),
        }
        groups[key][typ].append(item)

    created = 0
    for _, g in groups.items():
        t = Template(name=g["name"], element=g["element"], proficiency=g["proficiency"], version=g["version"])
        db.add(t); db.flush()
        for k in g["K"]:
            db.add(KnowledgeItem(template_id=t.id, **k))
        for p in g["P"]:
            db.add(PerformanceItem(template_id=t.id, **p))
        created += 1
    db.commit()
    return {"templates_created": created}
