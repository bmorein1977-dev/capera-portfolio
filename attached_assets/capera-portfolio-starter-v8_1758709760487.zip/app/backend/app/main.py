from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session
from app.api import auth, health, framework, ai, uploads, templates, assessments, verification, reports, signatures
from app.api import assessment_pdf, template_import, clients
from app.db import engine, Base, SessionLocal
from app.models.category import Category
from app.models.user import User
from app.models.template import Template, KnowledgeItem, PerformanceItem
from app.models.assessment import Assessment, AssessmentLine
from app.models.verification import SamplingPolicy, VerificationCheck
from app.models.signature import Signature
from app.models.client import Client
from app.core.config import settings

app = FastAPI(title=settings.PROJECT_NAME, version=settings.VERSION)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
app.mount("/files", StaticFiles(directory=settings.UPLOAD_DIR), name="files")
app.include_router(health.router, prefix="/health", tags=["health"])
app.include_router(auth.router, prefix="/auth", tags=["auth"])
app.include_router(framework.router, prefix="/framework", tags=["framework"])
app.include_router(ai.router, prefix="/ai", tags=["ai"])
app.include_router(uploads.router, prefix="/uploads", tags=["uploads"])
app.include_router(templates.router, prefix="/templates", tags=["templates"])
app.include_router(assessments.router, prefix="/assessments", tags=["assessments"])
app.include_router(verification.router, prefix="/verification", tags=["verification"])
app.include_router(reports.router, prefix="/reports", tags=["reports"])
app.include_router(signatures.router, prefix="/signatures", tags=["signatures"])
app.include_router(assessment_pdf.router, prefix="/assessment-pdf", tags=["export"])
app.include_router(template_import.router, prefix="/template-import", tags=["templates"])
app.include_router(clients.router, prefix="/clients", tags=["clients"])

@app.on_event("startup")
def on_startup():
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as db:
        if db.query(Category).count() == 0:
            db.add_all([
                Category(code="OPS", name="Operations", description="Operations elements"),
                Category(code="MAINT", name="Maintenance", description="Maintenance elements"),
                Category(code="SAFE", name="Safety", description="Safety-critical elements", safety_criticality="High"),
            ]); db.commit()
