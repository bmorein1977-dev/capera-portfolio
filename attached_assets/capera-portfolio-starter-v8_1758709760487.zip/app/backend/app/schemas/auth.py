from pydantic import BaseModel, EmailStr

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"

class UserOut(BaseModel):
    id: int
    email: EmailStr
    first_name: str | None = ""
    last_name: str | None = ""
    role: str
    locale: str
    class Config: from_attributes = True

class UserCreate(BaseModel):
    email: EmailStr
    password: str
    first_name: str | None = ""
    last_name: str | None = ""
    role: str = "Assessor"
    locale: str = "en"

class LoginReq(BaseModel):
    email: EmailStr
    password: str
