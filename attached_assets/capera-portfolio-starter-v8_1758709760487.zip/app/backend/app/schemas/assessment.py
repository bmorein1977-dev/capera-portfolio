from pydantic import BaseModel
from typing import List

class AssessmentCreate(BaseModel):
    candidate_name: str
    template_id: int

class AssessmentOut(BaseModel):
    id: int
    candidate_name: str
    template_id: int
    status: str
    outcome: str
    class Config: from_attributes = True

class LineUpdate(BaseModel):
    id: int
    outcome: str  # C | SG | NA
    comments: str = ""
