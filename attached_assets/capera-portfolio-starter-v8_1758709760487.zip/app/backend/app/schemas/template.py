from pydantic import BaseModel
from typing import List

class KnowledgeItemIn(BaseModel):
    code: str
    text: str
    guidance: str = ""
    is_optional: bool = False
    weight: int = 1

class PerformanceItemIn(BaseModel):
    code: str
    text: str
    guidance: str = ""
    is_optional: bool = False
    weight: int = 1

class TemplateCreate(BaseModel):
    name: str
    element: str
    proficiency: str = "Basic"
    version: str = "1.0"
    knowledge: List[KnowledgeItemIn] = []
    performance: List[PerformanceItemIn] = []

class TemplateOut(BaseModel):
    id: int
    name: str
    element: str
    proficiency: str
    version: str
    class Config: from_attributes = True
