# Capera Portfolio Starter (v5)

MVP for competence e-portfolio on Replit.

## Run
Backend
```
cd app/backend
pip install -r requirements.txt
cp .env.example .env  # optional
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```
Frontend
```
cd app/frontend
npm i
npm run dev -- --host
```
Set `VITE_API_BASE` to backend URL if needed.

## Features
- Auth (register/login/me) with JWT (PyJWT), bcrypt
- SQLite via SQLAlchemy
- Templates (K/P items) + AI draft stub
- Assessments (lines, outcomes C/SG/NA) + **Assessor closes** assessment
- Verification sampling (QA-only, non-blocking)
- Optional Signatures (Assessor/Candidate/Verifier)
- Reports: Skills-gap totals, heatmap + CSV/PDF export
- Offline evidence capture (IndexedDB) + upload API

## New in v6
- Assessment **PDF export** with embedded signatures & line outcomes.
- **Role-aware UI**: Verify/Reports links appear only for permitted roles.
- **Templates bulk CSV import** endpoint & UI.

## New in v7
- **Client logos**: manage clients and upload logos (Admin only). Logos appear on **Assessment PDFs** and **Reports PDF** (pass `?client_id=...`).
- **Client selection**: choose a client when starting an assessment; that logo appears on the assessment export.
- Endpoints:
  - `GET/POST /clients`, `POST /clients/{id}/logo`
  - Assessment create accepts `client_id`.
  - Reports PDF: `GET /reports/skills-gaps.pdf?client_id=123`

## New in v8
- **Excel export**: `GET /reports/skills-gaps.xlsx?client_id=ID` embeds the selected client's **logo** in the sheet header. CSVs can't carry images; use Excel for branded spreadsheets.
