-- 801_cleanup_orphan_data.sql
DO $$
BEGIN
  IF to_regclass('assessor_allocations') IS NOT NULL THEN
    DELETE FROM assessor_allocations aa
    WHERE NOT EXISTS (SELECT 1 FROM users u WHERE u.id = aa.candidate_id);
    DELETE FROM assessor_allocations aa
    WHERE NOT EXISTS (SELECT 1 FROM users u WHERE u.id = aa.assessor_id);
  END IF;
END $$;

DELETE FROM assessments a
WHERE NOT EXISTS (SELECT 1 FROM users u WHERE u.id = a.candidate_id);
