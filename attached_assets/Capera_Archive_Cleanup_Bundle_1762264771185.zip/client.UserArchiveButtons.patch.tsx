// client.UserArchiveButtons.patch.tsx
import React, { useState } from 'react'
export function UserArchiveButtons({ userId, isArchived, onChange }: { userId: string; isArchived: boolean; onChange?: () => void; }) {
  const [busy, setBusy] = useState(false)
  async function call(path: string) {
    try {
      setBusy(true)
      const res = await fetch(path, { method: 'POST' })
      if (!res.ok) throw new Error('Request failed')
      onChange?.()
    } catch (e) {
      console.error(e)
      alert('Action failed')
    } finally {
      setBusy(false)
    }
  }
  return isArchived ? (
    <button className="btn btn-success" disabled={busy} onClick={() => call(`/api/users/${userId}/reactivate`)}>Reactivate</button>
  ) : (
    <button className="btn btn-warning" disabled={busy} onClick={() => call(`/api/users/${userId}/archive`)}>Archive</button>
  )
}
