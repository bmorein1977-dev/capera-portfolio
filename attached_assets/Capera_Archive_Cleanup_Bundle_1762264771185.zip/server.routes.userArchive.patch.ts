// server.routes.userArchive.patch.ts
import type { Request, Response } from 'express'
import { z } from 'zod'
import { db } from './storage'

export async function archiveUser(req: Request, res: Response) {
  const id = z.string().uuid().parse(req.params.id)
  await db.raw(`UPDATE users SET is_archived = TRUE WHERE id = $1`, [id])
  res.json({ ok: true })
}
export async function reactivateUser(req: Request, res: Response) {
  const id = z.string().uuid().parse(req.params.id)
  await db.raw(`UPDATE users SET is_archived = FALSE WHERE id = $1`, [id])
  res.json({ ok: true })
}
