# Filter out archived users
Always add `WHERE is_archived IS NOT TRUE` to hide archived users in lists and dashboards.
