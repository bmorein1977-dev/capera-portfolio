// server.routes.assessorCandidates.filter.patch.ts
import type { Request, Response } from 'express'
import { z } from 'zod'
import { db } from './storage'

export async function getAssessorCandidatesFiltered(req: Request, res: Response) {
  const assessorId = z.string().uuid().parse(req.params.id)
  const rows = await db.raw(`
    SELECT DISTINCT u.id, u.display_name, u.email, u.job_role_id
    FROM users u
    JOIN assessor_allocations aa ON aa.candidate_id = u.id
    WHERE aa.assessor_id = $1
      AND u.is_archived IS NOT TRUE
    ORDER BY u.display_name
  `, [assessorId])
  res.json(rows)
}
