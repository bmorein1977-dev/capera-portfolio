# Capera — Archive & Orphan Cleanup
Apply order:
1) 801_cleanup_orphan_data.sql
2) 802_add_is_archived_column.sql

Server routes (in server/routes.ts):
```ts
import { archiveUser, reactivateUser } from './routes.userArchive.patch'
import { getAssessorCandidatesFiltered } from './routes.assessorCandidates.filter.patch'
app.post('/api/users/:id/archive', archiveUser)
app.post('/api/users/:id/reactivate', reactivateUser)
app.get('/assessors/:id/candidates', getAssessorCandidatesFiltered)
```
Frontend: use `UserArchiveButtons` in the User Management card.
