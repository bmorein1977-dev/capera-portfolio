-- 802_add_is_archived_column.sql
ALTER TABLE users
  ADD COLUMN IF NOT EXISTS is_archived boolean NOT NULL DEFAULT false;
CREATE INDEX IF NOT EXISTS ix_users_is_archived ON users(is_archived);
